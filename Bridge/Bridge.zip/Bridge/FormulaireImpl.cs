using System;

public interface FormulaireImpl
{
  void dessineTexte(string texte);
  string gereZoneSaisie();
}

using System.Collections.Generic;

public abstract class Liasse
{
    public IList<Document> documents { get; protected set; }
}
